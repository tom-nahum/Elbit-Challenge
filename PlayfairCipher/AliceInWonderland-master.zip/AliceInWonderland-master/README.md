# Alice In Wonderland

## Welcome to the next stage of the puzzle. :black_heart: :chess_pawn:
###  Alice received the following message
    `Dear Alice, the rest of the story is in the attached letter.
      Only you and I can read it,
      Of course the way to open it is your name.
      In appreciation of Lyon playfair. `

#### Alice forgot how to decode the "cipher.txt" attachment.:thinking:
#### All you have to do is decrypt it and fill the following form https://forms.gle/fcsYYLQypK77VfZn6

The answers should contain:
- [x] Code to solve the first challenge
- [x] Code to solve the second challenge
